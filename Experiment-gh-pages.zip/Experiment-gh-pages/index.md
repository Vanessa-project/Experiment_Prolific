# Experiment: Offsetting 
## Thank you 

Thank you for participating in the study by Lars Schlereth and Vanessa Schoeller from the University of Regensburg.




![](https://github.com/Vanessa-project/Experiment/raw/gh-pages/logo_regensburg.jpg)


## Donation receipt

Below you can see the donation receipt.

![](https://github.com/Vanessa-project/Experiment/raw/gh-pages/monetary-donation.jpg)

## Calculation of the donation amount

Here we aim to explain how the donation amount is calculated.
x paticipants took part in the experiment. 
On average the participants solved y sliders in task 1, which resulted in a donation of ... €. 
z participants donated money to the offsetting chartiy in task 2, which leads to an additional donation of ... €
Therefore we as the experimenter donated ... € to atmosfair, which you can also see in the donation receipt above.


